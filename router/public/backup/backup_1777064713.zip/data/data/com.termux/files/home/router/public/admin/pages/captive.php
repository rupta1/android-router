<h2>🌐 Captive Portal Users</h2>

<style>
body{
    font-family: Arial;
}

.card{
    background:#1e293b;
    padding:20px;
    border-radius:12px;
    margin-bottom:20px;
}

.form{
    max-width:500px;
}

input, select{
    width:100%;
    padding:10px;
    margin-bottom:10px;
    border-radius:6px;
    border:none;
}

button{
    padding:10px;
    border:none;
    border-radius:8px;
    cursor:pointer;
    font-weight:bold;
}

/* GRID */
.grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(260px,1fr));
    gap:15px;
}

/* USER CARD */
.user-card{
    background:#111827;
    padding:15px;
    border-radius:12px;
    box-shadow:0 0 10px rgba(0,0,0,0.4);
}

.user-title{
    font-size:18px;
    font-weight:bold;
    margin-bottom:8px;
}

.info{
    font-size:14px;
    margin:3px 0;
    color:#cbd5f5;
}

/* BUTTON GROUP */
.btn-group{
    display:flex;
    gap:8px;
    margin-top:10px;
}

.btn{
    flex:1;
    padding:8px;
    font-size:13px;
    border-radius:6px;
    text-align:center;
}

.create-btn{
    width:100%;
    background:#3b82f6;
    color:white;
}

.flush{
    background:#f59e0b;
    color:white;
}

.delete{
    background:#ef4444;
    color:white;
}

.top-btn{
    background:#10b981;
    color:white;
    width:100%;
    margin-bottom:10px;
}
</style>

<!-- CREATE USER -->
<div class="card">
     <div class="form">
          <h3>Create User</h3>

<input id="u" placeholder="Username">
<input id="p" placeholder="Password">

<label>Speed Limit</label>
<select id="speed">
<option value="unlimited">Unlimited</option>
<option value="1mbit">1 Mbps</option>
<option value="2mbit">2 Mbps</option>
<option value="5mbit">5 Mbps</option>
</select>

<label>Session Time</label>
<select id="session">
<option value="unlimited">Unlimited</option>
<option value="30">30 min</option>
<option value="60">1 hour</option>
<option value="120">2 hour</option>
</select>

<label>Total Data</label>
<select id="data">
<option value="unlimited">Unlimited</option>
<option value="100">100 MB</option>
<option value="500">500 MB</option>
<option value="1024">1 GB</option>
</select>

<button class="create-btn" onclick="createUser()">Create User</button>
     </div>
</div>

<!-- USERS LIST -->
<div class="card">
<h3>Users List</h3>

<button class="top-btn" onclick="flushAll()">Flush All Users</button>

<div id="users" class="grid"></div>
</div>

<script src="../js/captive.js"></script>
