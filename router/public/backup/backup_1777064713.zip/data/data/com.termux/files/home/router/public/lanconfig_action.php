<?php
header('Content-Type: application/json');

$ssid = $_GET['ssid'] ?? '';
$pass = $_GET['pass'] ?? '';
$sec  = $_GET['sec']  ?? 'wpa2';
$band = $_GET['band'] ?? 'any';

if(!$ssid){
    echo json_encode(["msg"=>"SSID required"]);
    exit;
}

// sanitize
$ssid = escapeshellarg($ssid);
$pass = escapeshellarg($pass);

// stop hotspot
shell_exec("su -c 'cmd wifi stop-softap'");
sleep(2);

// ---------- FORCE BAND ----------
if($band == "2"){
    shell_exec("su -c 'cmd wifi force-softap-band enabled 2'");
}elseif($band == "5"){
    shell_exec("su -c 'cmd wifi force-softap-band enabled 5'");
}else{
    shell_exec("su -c 'cmd wifi force-softap-band disabled'");
}

// ---------- SECURITY FIX ----------
if($sec == "open"){
    $cmd = "cmd wifi start-softap $ssid open";
}else{
    // fallback to WPA2 if WPA3 unsupported
    if($sec == "wpa3"){
        $sec = "wpa2";
    }

    $cmd = "cmd wifi start-softap $ssid $sec $pass";
}

// start hotspot
shell_exec("su -c '$cmd'");

echo json_encode(["msg"=>"Hotspot updated successfully"]);
