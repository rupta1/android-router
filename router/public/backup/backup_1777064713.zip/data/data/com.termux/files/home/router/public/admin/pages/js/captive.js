// ================= FORMAT TIME =================
function formatTime(sec){
    sec = parseInt(sec) || 0;

    let h = Math.floor(sec/3600);
    let m = Math.floor((sec%3600)/60);
    let s = sec%60;

    return `${h}h ${m}m ${s}s`;
}

// ================= RENDER USERS =================
function renderUsers(data){

    let container = document.getElementById("users");
    let html = "";

    data.forEach(u=>{

        let dataBytes = parseInt(u.used_data) || 0;
        let timeSec   = parseInt(u.used_time) || 0;

        let usedMB = (dataBytes / 1024 / 1024).toFixed(2);
        let usedTime = formatTime(timeSec);

        html += `
        <div class="user-card">

            <div class="user-title">${u.user}</div>

            <div class="info">Speed: ${u.speed}</div>
            <div class="info">Session: ${u.session}</div>
            <div class="info">Data Plan: ${u.data}</div>

            <hr style="border:1px solid #334155">

            <div class="info">Used Data: ${usedMB} MB</div>
            <div class="info">Used Time: ${usedTime}</div>

            <div class="btn-group">
                <button class="btn flush" onclick="flushUser('${u.user}')">Flush</button>
                <button class="btn delete" onclick="deleteUser('${u.user}')">Delete</button>
            </div>

        </div>`;
    });

    container.innerHTML = html;
}

// ================= LOAD USERS (NO CACHE) =================
function loadUsers(){

    fetch("../../users_action.php?action=userlist&nocache=" + Date.now())
    .then(r=>r.json())
    .then(data=>{
        renderUsers(data);
    })
    .catch(()=>{
        console.log("Error loading users");
    });
}

// ================= AUTO REFRESH =================
setInterval(loadUsers, 2000);


// ================= CREATE =================
function createUser(){

    let u = document.getElementById("u").value;
    let p = document.getElementById("p").value;
    let s = document.getElementById("speed").value;
    let t = document.getElementById("session").value;
    let d = document.getElementById("data").value;

    if(!u || !p){
        alert("Username & password required");
        return;
    }

    fetch(`../../users_action.php?action=create&u=${u}&p=${p}&s=${s}&t=${t}&d=${d}`)
    .then(()=>{
        loadUsers();
    });
}

// ================= DELETE =================
function deleteUser(u){

    if(!confirm("Delete user " + u + "?")) return;

    fetch(`../../users_action.php?action=delete&u=${u}`)
    .then(()=>{
        loadUsers();
    });
}

// ================= FLUSH =================
function flushUser(u){

    if(!confirm("Reset usage for " + u + "?")) return;

    fetch(`../../users_action.php?action=flush&u=${u}`)
    .then(()=>{
        loadUsers();
    });
}

// ================= FLUSH ALL =================
function flushAll(){

    if(!confirm("Reset ALL users usage?")) return;

    fetch(`../../users_action.php?action=flush_all`)
    .then(()=>{
        loadUsers();
    });
}

// ================= INIT =================
loadUsers();